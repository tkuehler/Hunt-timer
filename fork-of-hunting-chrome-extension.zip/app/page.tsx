"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Search, MoreVertical } from "lucide-react"
import { texasCounties, texasCountySeasons } from "@/lib/texas-counties-data"

// Declare chrome variable for environments where it might not be defined
declare global {
  interface Window {
    chrome?: any
  }
}

export default function HunterCountdown() {
  const [currentTime, setCurrentTime] = useState("--:--")
  const [currentDate, setCurrentDate] = useState("Loading...")
  const [greeting, setGreeting] = useState("Welcome")
  const [countdowns, setCountdowns] = useState<any[]>([])
  const [userState, setUserState] = useState<string | null>(null)
  const [userCounty, setUserCounty] = useState<string | null>(null)
  const [customSeasons, setCustomSeasons] = useState<Record<string, any>>({})
  const [showCustomSeasonModal, setShowCustomSeasonModal] = useState(false)
  const [showLocationModal, setShowLocationModal] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showMenu, setShowMenu] = useState(false)
  const [seasonType, setSeasonType] = useState("")
  const [customName, setCustomName] = useState("")
  const [seasonDate, setSeasonDate] = useState("")
  const [backgroundImage, setBackgroundImage] = useState("/misty-forest-at-dawn-with-mountains.jpg")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loginEmail, setLoginEmail] = useState("")
  const [dailyQuote, setDailyQuote] = useState({ text: "", author: "" })
  const [customGameAnimal, setCustomGameAnimal] = useState("")
  const [showPrivacyModal, setShowPrivacyModal] = useState(false)
  const [showSeasonsModal, setShowSeasonsModal] = useState(false)
  const [searchExpanded, setSearchExpanded] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [backgroundLoaded, setBackgroundLoaded] = useState(false)
  const [locationLoading, setLocationLoading] = useState(false)
  const [locationError, setLocationError] = useState<string | null>(null)

  // Inspirational quotes
  const quotes = [
    {
      text: "Hunting is not a sport? It is a way to be intimate with nature.",
      author: "Aldo Leopold",
    },
    {
      text: "The wildlife and its habitat cannot speak, so we must and we will.",
      author: "Theodore Roosevelt",
    },
    {
      text: "There are some who can live without wild things, and some who cannot.",
      author: "Aldo Leopold",
    },
    {
      text: "Be sure you're right, then go ahead.",
      author: "Davy Crockett",
    },
    {
      text: "The true hunter counts his achievement in proportion to the effort involved and the fairness of the sport.",
      author: "Jack O'Connor",
    },
    {
      text: "In a civilized and cultivated country, wild animals only continue to exist at all when preserved by sportsmen.",
      author: "Theodore Roosevelt",
    },
    {
      text: "Conservation is a state of harmony between men and land.",
      author: "Aldo Leopold",
    },
    {
      text: "I never killed anything that wasn't coming at me.",
      author: "Davy Crockett",
    },
    {
      text: "The real trophy of a successful hunt is the experience itself and the memories that endure.",
      author: "Jack O'Connor",
    },
    {
      text: "The nation behaves well if it treats the natural resources as assets which it must turn over to the next generation increased, and not impaired, in value.",
      author: "Theodore Roosevelt",
    },
  ]

  // Background images
  const backgroundImages = [
    {
      url: "/misty-forest-at-dawn-with-mountains.jpg",
      season: "all",
      description: "Misty forest at dawn",
    },
    {
      url: "/majestic-mountain-landscape-wilderness.jpg",
      season: "all",
      description: "Mountain landscape",
    },
    {
      url: "/autumn-forest-with-fall-colors.jpg",
      season: "fall",
      description: "Autumn forest",
    },
    {
      url: "/snowy-winter-forest-landscape.jpg",
      season: "winter",
      description: "Snowy forest",
    },
    {
      url: "/spring-landscape-with-green-trees.jpg",
      season: "spring",
      description: "Spring landscape",
    },
    {
      url: "/foggy-mountains-at-sunrise.jpg",
      season: "all",
      description: "Foggy mountains",
    },
    {
      url: "/forest-path-through-tall-trees.jpg",
      season: "all",
      description: "Forest path",
    },
    {
      url: "/autumn-lake-with-reflection.jpg",
      season: "fall",
      description: "Autumn lake",
    },
  ]

  useEffect(() => {
    const img = new Image()
    img.onload = () => {
      setBackgroundLoaded(true)
    }
    img.onerror = () => {
      // Silently mark as loaded to prevent blocking the UI
      setBackgroundLoaded(true)
    }
    img.src = backgroundImage
  }, [backgroundImage])

  // States data
  const states = [{ code: "TX", name: "Texas" }]

  // State hunting laws URLs
  const stateHuntingLawsUrls: Record<string, string> = {
    TX: "https://tpwd.texas.gov/huntwild/hunt/",
  }

  // Hunting seasons data by state
  const huntingSeasonsByState: Record<string, Record<string, any>> = {
    // Default seasons
    default: {
      deer: { name: "Deer", month: 10, day: 1 },
      turkey: { name: "Turkey", month: 3, day: 15 },
      duck: { name: "Duck", month: 9, day: 1 },
      pheasant: { name: "Pheasant", month: 10, day: 15 },
      elk: { name: "Elk", month: 8, day: 15 },
    },

    // Texas seasons
    TX: {
      deer: { name: "Whitetail Deer", month: 10, day: 29 },
      turkey: { name: "Turkey", month: 3, day: 18 },
      dove: { name: "Dove", month: 8, day: 31 },
      quail: { name: "Quail", month: 9, day: 24 },
      duck: { name: "Duck", month: 10, day: 28 },
    },

    // Colorado seasons
    CO: {
      elk: { name: "Elk", month: 9, day: 2 },
      deer: { name: "Deer", month: 10, day: 15 },
      pronghorn: { name: "Pronghorn", month: 9, day: 1 },
      moose: { name: "Moose", month: 9, day: 9 },
      bear: { name: "Bear", month: 8, day: 15 },
    },

    // Wisconsin seasons
    WI: {
      deer: { name: "Deer", month: 10, day: 16 },
      turkey: { name: "Turkey", month: 3, day: 21 },
      bear: { name: "Bear", month: 8, day: 31 },
      grouse: { name: "Grouse", month: 8, day: 15 },
      duck: { name: "Duck", month: 9, day: 24 },
    },
  }

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      // Use Chrome's search API to respect user's default search provider
      if (typeof window.chrome !== "undefined" && window.chrome.search && window.chrome.search.query) {
        try {
          window.chrome.search.query(
            {
              text: searchQuery,
            },
            () => {
              // Handle any potential errors from the API call
              if (window.chrome.runtime.lastError) {
                console.error("Search error:", window.chrome.runtime.lastError)
                // Fallback to Google search if Chrome API fails
                window.open(`https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`, "_blank")
              }
            },
          )
        } catch (error) {
          console.error("Error using Chrome search API:", error)
          // Fallback to Google search if Chrome API throws an error
          window.open(`https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`, "_blank")
        }
      } else {
        // Fallback for development environment or if Chrome API is not available
        window.open(`https://www.google.com/search?q=${encodeURIComponent(searchQuery)}`, "_blank")
      }
      setSearchQuery("")
      setSearchExpanded(false)
    }
  }

  // Calculate season status - returns days until start OR days remaining if open
  const calculateSeasonStatus = (
    startMonth: number,
    startDay: number,
    endMonth?: number,
    endDay?: number
  ): { daysUntil: number; isOpen: boolean; daysRemaining: number } => {
    const now = new Date()
    const currentYear = now.getFullYear()

    // Create start and end dates for current season
    let startDate = new Date(currentYear, startMonth - 1, startDay)
    let endDate = endMonth && endDay ? new Date(currentYear, endMonth - 1, endDay) : null

    // Handle seasons that span across years (e.g., Nov - Jan)
    if (endDate && endDate < startDate) {
      // If we're before the start date this year, the season hasn't started
      if (now < startDate) {
        // Season starts this year and ends next year
        endDate = new Date(currentYear + 1, endMonth! - 1, endDay!)
      } else {
        // We might be in the season that started last year
        const lastYearStart = new Date(currentYear - 1, startMonth - 1, startDay)
        const thisYearEnd = new Date(currentYear, endMonth! - 1, endDay!)
        
        if (now <= thisYearEnd) {
          // We're in a season that started last year
          startDate = lastYearStart
          endDate = thisYearEnd
        } else {
          // Season ended, next one starts this year
          endDate = new Date(currentYear + 1, endMonth! - 1, endDay!)
        }
      }
    }

    // Check if season is currently open
    if (endDate && now >= startDate && now <= endDate) {
      const daysRemaining = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
      return { daysUntil: 0, isOpen: true, daysRemaining }
    }

    // Season not open - calculate days until start
    if (now > startDate) {
      // Start date passed, use next year
      startDate = new Date(currentYear + 1, startMonth - 1, startDay)
    }

    const daysUntil = Math.ceil((startDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    return { daysUntil, isOpen: false, daysRemaining: 0 }
  }

  // Legacy function for backward compatibility
  const daysUntil = (month: number, day: number) => {
    return calculateSeasonStatus(month, day).daysUntil
  }

  // Update time and date
  const updateTimeAndDate = () => {
    const now = new Date()

    // Format time in 12-hour format with AM/PM
    const hours = now.getHours()
    const minutes = now.getMinutes().toString().padStart(2, "0")
    const ampm = hours >= 12 ? "PM" : "AM"
    const displayHours = hours % 12 || 12 // Convert 0 to 12 for 12 AM
    setCurrentTime(`${displayHours}:${minutes} ${ampm}`)

    const options: Intl.DateTimeFormatOptions = { weekday: "long", month: "long", day: "numeric" }
    setCurrentDate(now.toLocaleDateString("en-US", options))

    // Update greeting
    if (hours < 12) {
      setGreeting("Good morning, it's only")
    } else if (hours < 18) {
      setGreeting("Good afternoon, it's only")
    } else {
      setGreeting("Good evening, it's only")
    }
  }

  const detectLocation = async () => {
    setLocationLoading(true)
    setLocationError(null)

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser")
      setLocationLoading(false)
      return
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        console.log("[v0] Got coordinates:", latitude, longitude)

        try {
          // Use reverse geocoding to get county
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=10`,
          )
          const data = await response.json()
          console.log("[v0] Geocoding response:", data)

          if (data.address) {
            const county = data.address.county?.replace(" County", "")
            const state = data.address.state

            console.log("[v0] Detected location:", { county, state })

            if (state === "Texas" && county) {
              setUserState("TX")
              setUserCounty(county)
              saveUserSettings({ userState: "TX", userCounty: county })
              setShowLocationModal(false)
            } else if (state === "Texas") {
              setUserState("TX")
              saveUserSettings({ userState: "TX" })
              setLocationError("Could not detect county. Please select manually.")
            } else {
              setLocationError("This feature is currently only available for Texas residents.")
            }
          }
        } catch (error) {
          console.error("[v0] Geocoding error:", error)
          setLocationError("Could not detect your location. Please select manually.")
        }

        setLocationLoading(false)
      },
      (error) => {
        console.error("[v0] Geolocation error:", error)
        setLocationError("Unable to access your location. Please select manually.")
        setLocationLoading(false)
      },
    )
  }

  useEffect(() => {
    if (userState === "TX" && userCounty && countdowns.length === 0) {
      // Auto-populate with Deer, Dove, Turkey
      const countySeasons = texasCountySeasons[userCounty]
      if (countySeasons) {
        const defaultSeasonKeys = ["whitetail_deer", "dove", "turkey_spring"]
        const newCountdowns = defaultSeasonKeys
          .filter((key) => countySeasons[key])
          .map((key) => {
            const season = countySeasons[key]
            const status = calculateSeasonStatus(season.month, season.day, season.endMonth, season.endDay)
            return {
              id: key,
              name: season.name,
              daysUntil: status.daysUntil,
              isOpen: status.isOpen,
              daysRemaining: status.daysRemaining,
            }
          })
        setCountdowns(newCountdowns)
      }
    }
  }, [userCounty, userState])

  // Update countdowns
  const updateCountdowns = () => {
    let seasonsToUse

    if (userState === "TX" && userCounty) {
      // Get county-specific seasons from texas-counties-data.ts
      const countySeasons = texasCountySeasons[userCounty]

      if (countySeasons) {
        seasonsToUse = countySeasons
      } else {
        seasonsToUse = huntingSeasonsByState.TX
      }
    } else {
      // Get seasons for user's state or use default
      seasonsToUse =
        userState && huntingSeasonsByState[userState] ? huntingSeasonsByState[userState] : huntingSeasonsByState.default
    }

    // Combine state seasons with custom seasons
    const allSeasons = { ...seasonsToUse, ...customSeasons }

    // Only update if we have user-created countdowns
    if (Object.keys(customSeasons).length === 0 && countdowns.length === 0) {
      return
    }

    // Calculate days until each season and create sorted array
    const seasonsArray = Object.entries(allSeasons).map(([key, season]: [string, any]) => {
      const status = calculateSeasonStatus(season.month, season.day, season.endMonth, season.endDay)
      return {
        id: key,
        name: season.name,
        daysUntil: status.daysUntil,
        isOpen: status.isOpen,
        daysRemaining: status.daysRemaining,
      }
    })

    // Sort: open seasons first (by days remaining), then upcoming (by days until)
    seasonsArray.sort((a, b) => {
      if (a.isOpen && !b.isOpen) return -1
      if (!a.isOpen && b.isOpen) return 1
      if (a.isOpen && b.isOpen) return a.daysRemaining - b.daysRemaining
      return a.daysUntil - b.daysUntil
    })

    setCountdowns(seasonsArray)
  }

  // Set daily background and quote
  const setDailyContent = () => {
    try {
      // Get today's date as a string to use as a seed
      const today = new Date().toISOString().split("T")[0]

      // Use the date string to create a deterministic "random" index
      // This ensures the same image and quote are shown all day, but changes daily
      let hash = 0
      for (let i = 0; i < today.length; i++) {
        hash = (hash << 5) - hash + today.charCodeAt(i)
        hash = hash & hash // Convert to 32bit integer
      }

      // Get a positive index within the range of our images and quotes
      const imageIndex = Math.abs(hash) % backgroundImages.length
      const quoteIndex = Math.abs(hash + 1) % quotes.length // +1 to make it different from image

      // Set background image with fallback
      const selectedImage = backgroundImages[imageIndex]
      if (selectedImage && selectedImage.url) {
        setBackgroundImage(selectedImage.url)
      } else {
        // Fallback to first image if the selected one is invalid
        setBackgroundImage(backgroundImages[0].url)
      }

      setDailyQuote(quotes[quoteIndex])
    } catch (error) {
      console.error("Error setting daily content:", error)
      // Fallback to a default image if there's an error
      setBackgroundImage("/misty-forest-at-dawn-with-mountains.jpg")
    }
  }

  // Add custom season
  const addCustomSeason = (e: React.FormEvent) => {
    e.preventDefault()

    if (!seasonType || !seasonDate) return

    let name
    if (seasonType === "custom") {
      if (!customName) return
      name = customName
    } else {
      name = seasonType.charAt(0).toUpperCase() + seasonType.slice(1)
    }

    // Parse the date
    const date = new Date(seasonDate)
    const month = date.getMonth() + 1 // JavaScript months are 0-indexed
    const day = date.getDate()

    // Add the new season
    const newCustomSeasons = {
      ...customSeasons,
      [seasonType.toLowerCase()]: {
        name,
        month,
        day,
      },
    }

    setCustomSeasons(newCustomSeasons)
    saveUserSettings({ customSeasons: newCustomSeasons })

    // Reset form and close modal
    setSeasonType("")
    setCustomName("")
    setSeasonDate("")
    setShowCustomSeasonModal(false)
  }

  // Add custom game animal
  const addCustomGameAnimal = (e: React.FormEvent) => {
    e.preventDefault()

    if (!customGameAnimal || !seasonDate) return

    // Parse the date
    const date = new Date(seasonDate)
    const month = date.getMonth() + 1
    const day = date.getDate()

    // Create a unique key for the custom animal
    const key = `custom_${Date.now()}`

    // Add the new season
    const newCustomSeasons = {
      ...customSeasons,
      [key]: {
        name: customGameAnimal,
        month,
        day,
      },
    }

    setCustomSeasons(newCustomSeasons)
    saveUserSettings({ customSeasons: newCustomSeasons })

    // Reset form and close modal
    setCustomGameAnimal("")
    setSeasonDate("")
    setShowCustomSeasonModal(false)
  }

  // Set user state
  const saveUserState = (e: React.FormEvent) => {
    e.preventDefault()

    if (!userState) return

    saveUserSettings({ userState, userCounty })
    setShowLocationModal(false)
    updateCountdowns()
  }

  // Handle login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !password) return

    // For Chrome Web Store compliance, we're using local storage only
    // In a production app, you would validate with a secure backend
    setIsLoggedIn(true)
    setLoginEmail(email)

    // Store minimal information in localStorage
    localStorage.setItem("isLoggedIn", "true")
    localStorage.setItem("loginEmail", email)

    // Load user settings if they exist
    loadUserSettingsFromEmail(email)

    // Close modal
    setShowLoginModal(false)

    // Clear form fields for security
    setEmail("")
    setPassword("")
  }

  // Handle logout
  const handleLogout = () => {
    // Clear all user data
    setIsLoggedIn(false)
    setLoginEmail("")
    setUserState(null)
    setUserCounty(null) // Clear county on logout
    setCustomSeasons({})

    // Remove from localStorage
    localStorage.removeItem("isLoggedIn")
    localStorage.removeItem("loginEmail")
    localStorage.removeItem("userState") // Remove saved state
    localStorage.removeItem("userCounty") // Remove saved county

    // Clear any settings associated with the user
    if (loginEmail) {
      localStorage.removeItem(`settings_${loginEmail}`)
    }

    setShowMenu(false)

    // Update UI after logout
    updateCountdowns()
  }

  // Save user settings
  const saveUserSettings = (settings: any) => {
    if (!isLoggedIn || !loginEmail) {
      if (settings.userCounty) {
        localStorage.setItem("userCounty", settings.userCounty)
      }
      if (settings.userState) {
        localStorage.setItem("userState", settings.userState)
      }
      return
    }

    try {
      // Get existing settings or create new object
      const existingSettings = JSON.parse(localStorage.getItem(`settings_${loginEmail}`) || "{}")

      // Merge new settings
      const newSettings = { ...existingSettings, ...settings }

      // Save to localStorage
      localStorage.setItem(`settings_${loginEmail}`, JSON.stringify(newSettings))
    } catch (error) {
      console.error("Error saving user settings:", error)
      // Consider showing a user-friendly error message
    }
  }

  // Load user settings from email
  const loadUserSettingsFromEmail = (email: string) => {
    try {
      const settings = JSON.parse(localStorage.getItem(`settings_${email}`) || "{}")

      if (settings.userState) {
        setUserState(settings.userState)
      }

      if (settings.userCounty) {
        setUserCounty(settings.userCounty)
      }

      if (settings.customSeasons) {
        setCustomSeasons(settings.customSeasons)
      }
    } catch (error) {
      console.error("Error loading user settings:", error)
      // Consider showing a user-friendly error message
    }
  }

  // Remove a season
  const removeSeason = (seasonId: string) => {
    // Filter out the season with the given ID from the countdowns array
    const updatedCountdowns = countdowns.filter((season) => season.id !== seasonId)
    setCountdowns(updatedCountdowns)

    // If it's a custom season, also remove it from customSeasons
    if (customSeasons[seasonId]) {
      const updatedSeasons = { ...customSeasons }
      delete updatedSeasons[seasonId]
      setCustomSeasons(updatedSeasons)

      // Save to user settings
      saveUserSettings({ customSeasons: updatedSeasons })
    }
  }

  // Load saved data on initial render
  useEffect(() => {
    // Check if user is logged in
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    const email = localStorage.getItem("loginEmail")

    if (loggedIn && email) {
      setIsLoggedIn(true)
      setLoginEmail(email)
      loadUserSettingsFromEmail(email)
    } else {
      const savedState = localStorage.getItem("userState")
      const savedCounty = localStorage.getItem("userCounty")

      if (savedState) {
        setUserState(savedState)
      }
      if (savedCounty) {
        setUserCounty(savedCounty)
      }

      if (!savedState) {
        // If not logged in and no state set, show location modal
        setShowLocationModal(true)
      }
    }

    // Set daily background and quote
    setDailyContent()

    // Update time and countdowns
    updateTimeAndDate()
    const timeInterval = setInterval(updateTimeAndDate, 60000)

    // Preload all background images
    backgroundImages.forEach((img) => {
      const image = new Image()
      image.src = img.url
    })

    return () => {
      clearInterval(timeInterval)
    }
  }, [])

  // Update countdowns when user state or custom seasons change
  useEffect(() => {
    updateCountdowns()
  }, [userState, userCounty, customSeasons])

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement
      if (showMenu && !target.closest(".menu-container")) {
        setShowMenu(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [showMenu])

  const getAvailableSeasons = () => {
    let seasonsToUse

    if (userState === "TX" && userCounty) {
      const countySeasons = texasCountySeasons[userCounty]
      seasonsToUse = countySeasons || huntingSeasonsByState.TX
    } else {
      seasonsToUse =
        userState && huntingSeasonsByState[userState] ? huntingSeasonsByState[userState] : huntingSeasonsByState.default
    }

    return seasonsToUse
  }

  const handleCustomSeasonSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!seasonType) return

    const availableSeasons = getAvailableSeasons()
    const selectedSeason = availableSeasons[seasonType]

    if (selectedSeason) {
      const newCustomSeasons = {
        ...customSeasons,
        [seasonType]: selectedSeason,
      }
      setCustomSeasons(newCustomSeasons)
      saveUserSettings({ customSeasons: newCustomSeasons })
    } else if (customName && seasonDate) {
      // If custom date is provided, use it
      const [month, day] = seasonDate.split("-").map(Number)
      const newCustomSeasons = {
        ...customSeasons,
        [seasonType]: { name: customName, month, day },
      }
      setCustomSeasons(newCustomSeasons)
      saveUserSettings({ customSeasons: newCustomSeasons })
    }

    setShowCustomSeasonModal(false)
    setSeasonType("")
    setCustomName("")
    setSeasonDate("")
  }

  return (
    <div
      className="relative h-screen w-full overflow-hidden"
      style={{
        backgroundColor: "#000", // Fallback color
      }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: "cover",
          backgroundPosition: "center center",
          backgroundRepeat: "no-repeat",
          width: "100%",
          height: "100%",
        }}
      />

      {/* Overlay */}
      <div className="absolute inset-0 bg-black/30 z-0"></div>

      <div className="relative z-10 flex h-full w-full items-center justify-center">
        {/* Quote at the top */}
        <div className="absolute left-0 right-0 top-4 mx-auto w-4/5 max-w-2xl text-center">
          <p className="text-sm font-light italic text-white/90">"{dailyQuote.text}"</p>
          <p className="mt-1 text-xs text-white/70">— {dailyQuote.author}</p>
        </div>

        {/* Search icon/bar in upper left */}
        <div className="absolute left-6 top-6 z-20">
          <div className={`flex items-center transition-all duration-300 ${searchExpanded ? "w-64" : "w-10"}`}>
            <button
              onClick={() => setSearchExpanded(!searchExpanded)}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
              aria-label="Search"
            >
              <Search size={20} />
            </button>

            {searchExpanded && (
              <form className="ml-2 flex-1" onSubmit={handleSearch}>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search..."
                  className="w-full rounded-full bg-white/20 px-4 py-2 text-white placeholder-white/60 outline-none focus:bg-white/30"
                  autoFocus
                />
              </form>
            )}
          </div>
        </div>

        <div className="container mx-auto flex h-[90vh] max-w-4xl flex-col items-center justify-between px-4 py-10">
          {/* Menu button (three dots) */}
          <div className="menu-container absolute right-6 top-6 z-50">
            {isLoggedIn && (
              <div className="absolute right-0 -top-12 flex items-center gap-2">
                <span className="text-sm text-white/80">{loginEmail}</span>
                <button
                  onClick={handleLogout}
                  className="rounded-md bg-white/10 px-3 py-1 text-sm text-white hover:bg-white/20"
                  aria-label="Logout"
                >
                  Logout
                </button>
              </div>
            )}

            <button
              onClick={() => setShowMenu(!showMenu)}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
              aria-label="Menu"
            >
              <MoreVertical size={20} />
            </button>

            {showMenu && (
              <div className="absolute right-0 top-12 mt-2 w-48 overflow-hidden rounded-lg bg-white/90 shadow-lg backdrop-blur-sm">
                <button
                  onClick={() => {
                    setShowLocationModal(true)
                    setShowMenu(false)
                  }}
                  className="w-full px-4 py-2 text-left text-gray-800 hover:bg-white/50"
                >
                  Change Location
                </button>
                <button
                  onClick={() => {
                    setShowCustomSeasonModal(true)
                    setShowMenu(false)
                  }}
                  className="w-full px-4 py-2 text-left text-gray-800 hover:bg-white/50"
                >
                  Add Season
                </button>
                {userState === "TX" && userCounty && (
                  <button
                    onClick={() => {
                      setShowSeasonsModal(true)
                      setShowMenu(false)
                    }}
                    className="w-full px-4 py-2 text-left text-gray-800 hover:bg-white/50"
                  >
                    Select Game Animals
                  </button>
                )}
                {!isLoggedIn && (
                  <button
                    onClick={() => {
                      setShowLoginModal(true)
                      setShowMenu(false)
                    }}
                    className="w-full px-4 py-2 text-left text-gray-800 hover:bg-white/50"
                  >
                    Login
                  </button>
                )}
                <a
                  href={userState && stateHuntingLawsUrls[userState] ? stateHuntingLawsUrls[userState] : "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full px-4 py-2 text-left text-gray-800 hover:bg-white/50"
                  onClick={() => setShowMenu(false)}
                >
                  Hunting Laws
                </a>
                <button
                  onClick={() => {
                    setShowPrivacyModal(true)
                    setShowMenu(false)
                  }}
                  className="w-full px-4 py-2 text-left text-gray-800 hover:bg-white/50"
                >
                  Privacy Policy
                </button>
              </div>
            )}
          </div>

          {/* Time section */}
          <div className="mb-6 rounded-xl border border-white/20 bg-white/10 px-10 py-5 text-center backdrop-blur-md">
            <div className="mb-1 text-6xl font-extralight tracking-wider text-white">{currentTime}</div>
            <div className="text-lg font-light tracking-wide text-white">{currentDate}</div>
          </div>

          {/* Greeting */}
          <h1 className="mb-8 text-4xl font-extralight tracking-wide text-white drop-shadow-md">{greeting}</h1>

          {/* Countdowns - limited to 3 in a single row */}
          <div className="mb-auto flex w-full max-w-3xl justify-center gap-6 px-4">
            {countdowns.slice(0, 3).map((season) => (
              <div
                key={season.id}
                className={`group relative flex h-40 w-40 flex-shrink-0 flex-col items-center justify-center rounded-xl border p-4 text-center backdrop-blur-sm transition-transform hover:-translate-y-1 ${
                  season.isOpen
                    ? "border-green-400/50 bg-green-500/20 shadow-[0_0_15px_rgba(34,197,94,0.3)]"
                    : "border-white/20 bg-white/10"
                }`}
              >
                {/* Delete button - only visible on hover */}
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    removeSeason(season.id)
                  }}
                  className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-black/80 text-xs text-white hover:bg-black opacity-0 group-hover:opacity-100 transition-opacity"
                  aria-label={`Remove ${season.name} countdown`}
                >
                  ✕
                </button>
                {season.isOpen ? (
                  <>
                    <span className="mb-1 text-4xl font-extralight text-green-300">{season.daysRemaining}</span>
                    <span className="text-xs font-medium text-green-300">SEASON OPEN</span>
                    <span className="text-xs font-light text-green-200/80">{season.daysRemaining} days left</span>
                    <span className="mt-1 text-xs font-light text-white/70">{season.name}</span>
                  </>
                ) : (
                  <>
                    <span className="mb-1 text-5xl font-extralight text-white">{season.daysUntil}</span>
                    <span className="text-xs font-light text-white/80">Days until {season.name}</span>
                  </>
                )}
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="mt-6 flex flex-col items-center text-center text-sm text-white/70">
            {userCounty && (
              <div className="mb-2 text-xs text-white/60 font-light">
                {userCounty} County, {states.find((s) => s.code === userState)?.name || userState}
              </div>
            )}
            <span>Check your local wildlife agency for specific regulations</span>
            <div className="mt-1 italic">
              Location:{" "}
              {userState ? (
                <a
                  href={stateHuntingLawsUrls[userState] || "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white/90 hover:text-white underline"
                >
                  {states.find((s) => s.code === userState)?.name || userState}
                </a>
              ) : (
                "Not set"
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Modal overlay */}
      {(showCustomSeasonModal || showLocationModal || showLoginModal || showPrivacyModal || showSeasonsModal) && (
        <div
          className="absolute inset-0 z-20 bg-black/50"
          onClick={() => {
            setShowCustomSeasonModal(false)
            setShowLocationModal(false)
            setShowLoginModal(false)
            setShowPrivacyModal(false)
            setShowSeasonsModal(false)
          }}
        ></div>
      )}

      {/* Custom season modal */}
      {showCustomSeasonModal && (
        <div className="absolute left-1/2 top-1/2 z-30 w-96 max-w-[90%] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-white/20 bg-white/10 p-6 backdrop-blur-md">
          <div className="mb-5 flex items-center justify-between">
            <h3 className="text-2xl font-light text-white">Add Hunting Season</h3>
            <button onClick={() => setShowCustomSeasonModal(false)} className="text-xl text-white">
              ✕
            </button>
          </div>

          <form onSubmit={handleCustomSeasonSubmit} className="flex flex-col">
            <div className="mb-4">
              <label htmlFor="season-select" className="mb-1 block text-sm text-white/80">
                Select Game Animal
              </label>
              <select
                id="season-select"
                value={seasonType}
                onChange={(e) => {
                  setSeasonType(e.target.value)
                  const availableSeasons = getAvailableSeasons()
                  const selected = availableSeasons[e.target.value]
                  if (selected) {
                    setCustomName(selected.name)
                  } else {
                    setCustomName("") // Reset custom name if a non-custom season is selected
                  }
                }}
                required
                className="w-full rounded-lg border border-white/30 bg-white/20 p-2 text-white"
              >
                <option value="">Choose a season</option>
                {Object.entries(getAvailableSeasons()).map(([key, season]) => (
                  <option key={key} value={key}>
                    {season.name}
                  </option>
                ))}
                <option value="custom">Custom Season</option>
              </select>
            </div>

            {seasonType === "custom" && (
              <>
                <div className="mb-4">
                  <label htmlFor="season-name" className="mb-1 block text-sm text-white/80">
                    Season Name
                  </label>
                  <input
                    id="season-name"
                    type="text"
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    required
                    className="w-full rounded-lg border border-white/30 bg-white/20 p-2 text-white placeholder-white/50"
                    placeholder="e.g., Archery Deer"
                  />
                </div>

                <div className="mb-4">
                  <label htmlFor="season-date" className="mb-1 block text-sm text-white/80">
                    Start Date (MM-DD)
                  </label>
                  <input
                    id="season-date"
                    type="text"
                    value={seasonDate}
                    onChange={(e) => setSeasonDate(e.target.value)}
                    required
                    pattern="[0-9]{1,2}-[0-9]{1,2}"
                    className="w-full rounded-lg border border-white/30 bg-white/20 p-2 text-white placeholder-white/50"
                    placeholder="MM-DD (e.g., 10-15)"
                  />
                </div>
              </>
            )}

            <button
              type="submit"
              className="mt-2 rounded-lg bg-white/20 py-2 text-white transition-colors hover:bg-white/30"
            >
              Add Season
            </button>
          </form>
        </div>
      )}

      {/* Location modal */}
      {showLocationModal && (
        <div className="absolute left-1/2 top-1/2 z-30 w-96 max-w-[90%] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-white/20 bg-white/10 p-6 backdrop-blur-md">
          <div className="mb-5 flex items-center justify-between">
            <h3 className="text-2xl font-light text-white">Set Your Location</h3>
            <button onClick={() => setShowLocationModal(false)} className="text-xl text-white">
              ✕
            </button>
          </div>

          <div className="mb-6">
            <button
              type="button"
              onClick={detectLocation}
              disabled={locationLoading}
              className="w-full rounded-lg bg-green-600/80 py-3 text-white transition-colors hover:bg-green-600 disabled:bg-gray-500/50 disabled:cursor-not-allowed"
            >
              {locationLoading ? "Detecting Location..." : "Auto-Detect My Location (Texas Only)"}
            </button>
            {locationError && <p className="mt-2 text-sm text-red-300">{locationError}</p>}
            {userCounty && <p className="mt-2 text-sm text-green-300">Detected: {userCounty} County, Texas</p>}
          </div>

          <div className="mb-4 flex items-center gap-2">
            <div className="flex-1 border-t border-white/30"></div>
            <span className="text-sm text-white/70">or select manually</span>
            <div className="flex-1 border-t border-white/30"></div>
          </div>

          <form onSubmit={saveUserState} className="flex flex-col">
            <div className="mb-4">
              <label htmlFor="state-select" className="mb-1 block text-sm text-white/80">
                Select Your State
              </label>
              <select
                id="state-select"
                value={userState || ""}
                onChange={(e) => setUserState(e.target.value)}
                required
                className="w-full rounded-lg border border-white/30 bg-white/20 p-2 text-white"
              >
                <option value="">Select State</option>
                {states.map((state) => (
                  <option key={state.code} value={state.code}>
                    {state.name}
                  </option>
                ))}
              </select>
            </div>

            {userState === "TX" && (
              <div className="mb-4">
                <label htmlFor="county-select" className="mb-1 block text-sm text-white/80">
                  Select Your County (Optional)
                </label>
                <select
                  id="county-select"
                  value={userCounty || ""}
                  onChange={(e) => setUserCounty(e.target.value)}
                  className="w-full rounded-lg border border-white/30 bg-white/20 p-2 text-white max-h-48 overflow-y-auto"
                >
                  <option value="">Select County</option>
                  {texasCounties.map((county) => (
                    <option key={county} value={county}>
                      {county}
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-xs text-white/60">Select your county for more accurate hunting season dates</p>
              </div>
            )}

            <button
              type="submit"
              className="mt-2 rounded-lg bg-white/20 py-2 text-white transition-colors hover:bg-white/30"
            >
              Save Location
            </button>
          </form>
        </div>
      )}

      {showLoginModal && (
        <div className="absolute left-1/2 top-1/2 z-30 w-96 max-w-[90%] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-white/20 bg-white/10 p-6 backdrop-blur-md">
          <div className="mb-5 flex items-center justify-between">
            <h3 className="text-2xl font-light text-white">Login</h3>
            <button onClick={() => setShowLoginModal(false)} className="text-xl text-white">
              ✕
            </button>
          </div>

          <form onSubmit={handleLogin} className="flex flex-col">
            <div className="mb-4">
              <label htmlFor="email" className="mb-1 block text-sm text-white/80">
                Email
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="your@email.com"
                className="w-full rounded-lg border border-white/30 bg-white/20 p-2 text-white placeholder-white/60"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="password" className="mb-1 block text-sm text-white/80">
                Password
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="w-full rounded-lg border border-white/30 bg-white/20 p-2 text-white placeholder-white/60"
              />
            </div>

            <button
              type="submit"
              className="mt-2 rounded-lg bg-white/20 py-2 text-white transition-colors hover:bg-white/30"
            >
              Login
            </button>

            <p className="mt-4 text-center text-xs text-white/60">For demo purposes, any email/password will work</p>
          </form>
        </div>
      )}

      {/* Select Game Animals modal */}
      {showSeasonsModal && userState === "TX" && userCounty && (
        <div className="absolute left-1/2 top-1/2 z-30 w-96 max-w-[90%] max-h-[80vh] overflow-auto -translate-x-1/2 -translate-y-1/2 rounded-xl border border-white/20 bg-white/10 p-6 backdrop-blur-md">
          <div className="mb-5 flex items-center justify-between">
            <h3 className="text-2xl font-light text-white">Select Game Animals</h3>
            <button onClick={() => setShowSeasonsModal(false)} className="text-xl text-white">
              ✕
            </button>
          </div>

          <p className="mb-4 text-sm text-white/70">
            Choose up to 3 game animals to display on your dashboard. Seasons with green indicators are currently open.
          </p>

          <div className="space-y-2 max-h-[50vh] overflow-auto">
            {Object.entries(texasCountySeasons[userCounty] || {}).map(([key, season]: [string, any]) => {
              const status = calculateSeasonStatus(season.month, season.day, season.endMonth, season.endDay)
              const isSelected = countdowns.some((c) => c.id === key)

              return (
                <button
                  key={key}
                  onClick={() => {
                    if (isSelected) {
                      // Remove from countdowns
                      setCountdowns(countdowns.filter((c) => c.id !== key))
                    } else if (countdowns.length < 3) {
                      // Add to countdowns
                      const newCountdown = {
                        id: key,
                        name: season.name,
                        daysUntil: status.daysUntil,
                        isOpen: status.isOpen,
                        daysRemaining: status.daysRemaining,
                      }
                      setCountdowns([...countdowns, newCountdown])
                    }
                  }}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-colors ${
                    isSelected
                      ? "bg-white/30 border border-white/40"
                      : "bg-white/10 border border-white/20 hover:bg-white/20"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        status.isOpen ? "bg-green-400 shadow-[0_0_8px_rgba(34,197,94,0.6)]" : "bg-white/30"
                      }`}
                    />
                    <span className="text-white text-sm">{season.name}</span>
                  </div>
                  <span className={`text-xs ${status.isOpen ? "text-green-300" : "text-white/60"}`}>
                    {status.isOpen ? `${status.daysRemaining}d left` : `${status.daysUntil}d`}
                  </span>
                </button>
              )
            })}
          </div>

          <div className="mt-4 pt-4 border-t border-white/20">
            <p className="text-xs text-white/50 text-center">
              {countdowns.length}/3 seasons selected
            </p>
          </div>
        </div>
      )}

      {/* Privacy Policy modal */}
      {showPrivacyModal && (
        <div className="absolute left-1/2 top-1/2 z-30 w-96 max-w-[90%] h-[80vh] overflow-auto -translate-x-1/2 -translate-y-1/2 rounded-xl border border-white/20 bg-white/10 p-6 backdrop-blur-md">
          <div className="mb-5 flex items-center justify-between">
            <h3 className="text-2xl font-light text-white">Privacy Policy</h3>
            <button onClick={() => setShowPrivacyModal(false)} className="text-xl text-white">
              ✕
            </button>
          </div>

          <div className="text-white/90 text-sm">
            <h4 className="text-lg mb-2">Hunter's Countdown Privacy Policy</h4>

            <p className="mb-2">Last Updated: {new Date().toLocaleDateString()}</p>

            <h5 className="font-semibold mt-4 mb-1">Information We Collect</h5>
            <p className="mb-2">We collect the following information to provide the Hunter's Countdown service:</p>
            <ul className="list-disc pl-5 mb-3">
              <li>Email address (for account identification only)</li>
              <li>Location data (state and county selection)</li>
              <li>Geolocation coordinates (only when you use auto-detect, not stored)</li>
              <li>Custom hunting season preferences</li>
            </ul>

            <h5 className="font-semibold mt-4 mb-1">How We Use Your Information</h5>
            <p className="mb-2">We use your information to:</p>
            <ul className="list-disc pl-5 mb-3">
              <li>Provide personalized hunting season countdowns based on your Texas county</li>
              <li>Save your preferences locally on your device</li>
              <li>Display accurate TPWD hunting regulations for your area</li>
            </ul>

            <h5 className="font-semibold mt-4 mb-1">Geolocation</h5>
            <p className="mb-3">
              When you use the auto-detect feature, your browser's geolocation is used only to determine your Texas
              county. The coordinates are sent to OpenStreetMap's free geocoding service and are not stored by us.
            </p>

            <h5 className="font-semibold mt-4 mb-1">Data Storage</h5>
            <p className="mb-3">
              All user data is stored locally on your device using browser storage. We do not transmit or store your
              personal information on external servers.
            </p>

            <h5 className="font-semibold mt-4 mb-1">Third-Party Services</h5>
            <p className="mb-3">
              This extension uses Chrome's Search API and OpenStreetMap's Nominatim API for reverse geocoding.
            </p>

            <h5 className="font-semibold mt-4 mb-1">Your Rights</h5>
            <p className="mb-3">
              You can delete all stored data by clearing your browser's local storage or by using the logout function.
            </p>

            <h5 className="font-semibold mt-4 mb-1">Contact</h5>
            <p className="mb-3">For questions about this privacy policy, please contact: example@huntercountdown.com</p>
          </div>
        </div>
      )}
    </div>
  )
}
